<?php wp_footer(); ?>

<footer role="contentinfo" class="group">

	<div class="wrap">
	<div class="grid-half footer-left">
	<p><strong>Tracey L. Jones Auctioneers, Inc.</strong></p>
<p>P.O.Box 545, Morgantown, PA  19543</p>
<p>Phone: (610) 286-7834    Mobile: (484) 332-5287</p>
<p>Email: tljauction@gmail.com</p>
	</div>

	<div class="grid-half footer-right">
<p><strong>Stay Informed</strong></p>
<p><i class="fa fa-facebook"></i> <i class="fa fa-twitter"></i> <i class="fa fa-envelope"></i></p>
<p>Company License #AY-2082  |  Auctioneer License #AU-3607-L</p>
<p>&copy; <?php echo date('Y'); ?> TLJ Auctioneers Inc., All right reserved. Web site by Web Tek, Ephrata PA</p>

	</div>
    
    </div>

</footer>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/slides.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/main.js"></script> 

<script>
  $(function() {
    $(".rslides").responsiveSlides();
  });
</script>

</body>
</html>